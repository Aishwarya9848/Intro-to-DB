﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBS_Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Teams values (@Team_ID,@Team_Name,@Match_ID,@Match_Points)", con);
            cmd.Parameters.AddWithValue("@Team_ID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@Team_Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Match_ID", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("@Match_Points", int.Parse(textBox4.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("inserted Team");
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update Teams set Team_name=@Team_Name, Match_ID=@Match_ID, Match_Points=@Match_Points where Team_ID=@Team_ID", con);
            cmd.Parameters.AddWithValue("@Team_ID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@Team_Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Match_ID", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("@Match_Points", int.Parse(textBox4.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Updated Teams");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete Teams where Team_ID=@Team_ID", con);
            cmd.Parameters.AddWithValue("@Team_ID", int.Parse(textBox1.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Deleted Team");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Teams", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 F3 = new Form3();
            F3.Show();
        }
    }
}
