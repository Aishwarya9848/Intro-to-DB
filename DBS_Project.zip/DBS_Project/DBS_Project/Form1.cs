using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;

namespace DBS_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Players values (@Player_ID,@First_Name,@Last_Name,@Team_ID)", con);
            cmd.Parameters.AddWithValue("@Player_ID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@First_Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Last_Name", textBox3.Text);
            cmd.Parameters.AddWithValue("@Team_ID", int.Parse(textBox4.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Inserted into players");

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update Players set First_name=@First_Name, Last_Name=@Last_Name, Team_Id=@Team_ID where Player_ID=@Player_ID", con);
            cmd.Parameters.AddWithValue("@Player_ID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@First_Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Last_Name", textBox3.Text);
            cmd.Parameters.AddWithValue("@Team_ID", int.Parse(textBox4.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Updated Players");
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete Players where Player_ID=@Player_ID", con);
            cmd.Parameters.AddWithValue("@Player_ID", int.Parse(textBox1.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Deleted Player");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Players", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 F3 = new Form3();
            F3.Show();

        }
    }
}