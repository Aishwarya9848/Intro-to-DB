﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBS_Project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Tournaments values (@Tournament_ID,@Tournament_Name,@Tournament_Level,@Prize)", con);
            cmd.Parameters.AddWithValue("@Tournament_ID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@Tournament_Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Tournament_Level", textBox3.Text);
            cmd.Parameters.AddWithValue("@Prize", int.Parse(textBox4.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("inserted Tournament");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update Tournaments set Tournament_Name=@Tournament_Name,Tournament_Level=@Tournament_Level,Prize=@Prize where Tournament_ID=@Tournament_ID", con);
            cmd.Parameters.AddWithValue("@Tournament_ID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@Tournament_Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Tournament_Level", textBox3.Text);
            cmd.Parameters.AddWithValue("@Prize", int.Parse(textBox4.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Updated Tournament");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete Tournaments where Tournament_ID=@Tournament_ID", con);
            cmd.Parameters.AddWithValue("@Tournament_ID", int.Parse(textBox1.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Deleted Tournament");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=AISHWARYA\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Tournaments", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 F3 = new Form3();
            F3.Show();
        }
    }
}
